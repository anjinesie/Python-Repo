:orphan:

.. automodule:: numpy.polynomial
   :no-members:
   :no-inherited-members:
   :no-special-members:

Configuration
-------------

.. autosummary:: 
   :toctree: generated/

   numpy.polynomial.set_default_printstyle
